import React from "react";
import { motion } from "framer-motion";
import { Shield, Target, Eye, Zap, Search, ChevronLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { IMAGES } from "@/assets/images";
import { ROUTE_PATHS } from "@/lib/index";

const springPresets = {
  gentle: { stiffness: 300, damping: 35 },
  smooth: { stiffness: 200, damping: 40 },
};

const fadeInUp = {
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
};

const values = [
  {
    title: "الانضباط",
    description: "الالتزام الصارم بالبروتوكولات التشغيلية والمواعيد المحددة.",
    icon: Shield,
  },
  {
    title: "الشفافية",
    description: "تقارير مفتوحة وقائمة على البيانات لتعزيز الثقة المؤسسية.",
    icon: Search,
  },
  {
    title: "السلامة التشغيلية",
    description: "نهج لا يقبل المساومة تجاه رفاهية السائقين وسلامة الأسطول.",
    icon: Shield,
  },
  {
    title: "سرعة القرار",
    description: "استجابة مرنة لذروة الطلب وتحولات السوق المتسارعة.",
    icon: Zap,
  },
  {
    title: "جودة الخدمة",
    description: "إنفاذ متسق لاتفاقيات مستوى الخدمة (SLA) في جميع مدن العمل.",
    icon: Target,
  },
];

const About: React.FC = () => {
  return (
    <div className="flex flex-col w-full overflow-hidden" dir="rtl">
      {/* قسم البطل (Hero Section) */}
      <section className="relative pt-32 pb-24 md:pt-48 md:pb-36 bg-slate-950">
        <div className="absolute inset-0 z-0">
          <img
            src={IMAGES.WAREHOUSE_OPS_7}
            alt="عمليات فيرست لاين"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/80 via-slate-950/40 to-background" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial="initial"
            animate="animate"
            variants={fadeInUp}
            transition={springPresets.smooth}
            className="max-w-3xl text-right"
          >
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              الخط الأول… طبقة التنفيذ داخل منظومة الاقتصاد الرقمي.
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 leading-relaxed font-light">
              لسنا تطبيقاً ولا منصة تملك الطلب. نحن مشغّل تنفيذ ميداني يضمن أن الطلب الرقمي يتحول إلى تجربة تسليم دقيقة، مستقرة، قابلة للتوسع.
            </p>
          </motion.div>
        </div>
      </section>

      {/* قسم الرسالة والرؤية */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              variants={fadeInUp}
              transition={springPresets.gentle}
              className="space-y-12 order-2 lg:order-1"
            >
              <div className="space-y-6">
                <h2 className="text-3xl font-bold flex items-center gap-3 text-foreground">
                  <Target className="text-primary w-8 h-8" />
                  رسالتنا
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  رفع استقرار التنفيذ في اقتصاد التوصيل الرقمي من خلال توفير بنية تحتية تشغيلية قوية وقابلة للتوسع ومنضبطة للغاية لأبرز المنصات في المنطقة.
                </p>
              </div>

              <div className="space-y-6">
                <h2 className="text-3xl font-bold flex items-center gap-3 text-foreground">
                  <Eye className="text-primary w-8 h-8" />
                  رؤيتنا
                </h2>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  أن نكون منصة التنفيذ الوطنية الأكثر موثوقية في الميل الأخير داخل المملكة.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={springPresets.smooth}
              className="relative rounded-2xl overflow-hidden shadow-2xl order-1 lg:order-2"
            >
              <img
                src={IMAGES.CORPORATE_MEETING_1}
                alt="التخطيط المؤسسي"
                className="w-full aspect-[4/3] object-cover"
              />
              <div className="absolute inset-0 border border-primary/10 rounded-2xl pointer-events-none" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* قسم القيم الجوهرية */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">قيمنا الجوهرية</h2>
            <p className="text-muted-foreground">
              ثقافتنا التشغيلية مبنية على خمسة مبادئ أساسية تقود كل عملية توصيل وكل قرار استراتيجي نتخذه.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial="initial"
                whileInView="animate"
                viewport={{ once: true }}
                variants={fadeInUp}
                transition={{ ...springPresets.gentle, delay: index * 0.1 }}
                className="bg-card p-8 rounded-xl border border-border shadow-sm hover:shadow-md transition-all group text-right"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary transition-colors">
                  <value.icon className="w-6 h-6 text-primary group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* قسم الاستراتيجية المؤسسية */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="bg-slate-900 rounded-3xl overflow-hidden flex flex-col lg:flex-row shadow-2xl">
            <div className="lg:w-1/2 p-12 lg:p-20 flex flex-col justify-center space-y-8 text-right">
              <span className="text-primary font-mono text-sm tracking-wider uppercase">الحياد الاستراتيجي</span>
              <h2 className="text-3xl md:text-5xl font-bold text-white leading-tight">
                شريك تنفيذ لعصر المنصات المتعددة
              </h2>
              <p className="text-slate-400 text-lg">
                تعمل فيرست لاين لوجستيكس كمشغل 3PL سعودي محايد. نحن لا ننافس المنصات على الطلب؛ بل نحل مشكلة ندرة التنفيذ من خلال توفير شبكات سائقين مستقرة وعالية القدرة في أكثر من 16 مدينة.
              </p>
              <div className="pt-4">
                <Link
                  to={ROUTE_PATHS.PLATFORMS}
                  className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full font-semibold hover:bg-primary/90 transition-colors"
                >
                  استكشف خدمات المنصات
                  <ChevronLeft className="w-4 h-4" />
                </Link>
              </div>
            </div>
            <div className="lg:w-1/2 relative min-h-[400px]">
              <img
                src={IMAGES.WAREHOUSE_OPS_7}
                alt="النطاق التشغيلي"
                className="absolute inset-0 w-full h-full object-cover grayscale opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-slate-900 via-transparent to-transparent" />
            </div>
          </div>
        </div>
      </section>

      {/* قسم الدعوة لاتخاذ إجراء (CTA) */}
      <section className="py-24 border-t border-border bg-card">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-8">جاهز لتوسيع نطاق عملياتك؟</h2>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to={ROUTE_PATHS.CONTACT}
              className="bg-primary text-primary-foreground px-10 py-4 rounded-full font-bold hover:shadow-lg hover:shadow-primary/20 transition-all"
            >
              تواصل مع فريقنا
            </Link>
            <Link
              to={ROUTE_PATHS.INVESTORS}
              className="bg-secondary text-secondary-foreground px-10 py-4 rounded-full font-bold hover:bg-secondary/80 transition-all"
            >
              نظرة عامة للمستثمرين
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;